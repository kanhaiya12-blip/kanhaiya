# Colorful Heart Web App

This is a small Flask website. When anyone opens the website URL, they see a colorful animated heart similar to the supplied reference.

## Run locally

1. Install Python.
2. Open a terminal in this folder.
3. Run:
   pip install flask
   python app.py
4. Open http://127.0.0.1:5000

## Put it online

Upload this project to a Python hosting service such as Render, Railway, or PythonAnywhere.

Start command:
gunicorn app:app

The generated public URL can then be shared with anyone.
